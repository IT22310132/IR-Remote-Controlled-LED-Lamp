﻿#include <Arduino.h>
#include <IRremote.h>

//============================== External Functions pre-definitions ==============================
void RGB_OFF();
void RED();
void GREEN();
void BLUE();
void RED_GREEN();
void RED_BLUE();
void GREEN_BLUE();
void RGB_WHITE();
//End

#define CH_UP 16769565							// Decimal code of Channel UP on IR remote.
#define CH_DOWN 16753245						// Decimal code of Channel DOWN on IR remote.
#define VOL_UP 16754775							// Decimal code of Volume UP on IR remote.
#define VOL_DOWN 16769055						// Decimal code of Volume UP on IR remote.

#define R 11									
#define G 12									
#define B 13									
int whiteLED[4] = { 5, 6, 9, 10 };				
	
const int RECEIVER_PIN = A0;					
int w_val = 0;
int rgb_val = 0;
int rgb_state = 0;
int rgb_cycle = -1;
int brightness = 255;

IRrecv irrecv(RECEIVER_PIN);
decode_results results;

void setup() {
	//=================================== Defining all LED pins as OUTPUT pins ===================================
  for (int i = 0; i < 4; i++) {
    pinMode(whiteLED[i], OUTPUT);
  }

  for (int i = 11; i <= 13; i++) {
    pinMode(i, OUTPUT);
  }
  
	//=================================== Upon start-up turn all LEDs OFF ===================================
  for (int i = 0; i < 4; i++) {
	  digitalWrite(whiteLED[i], LOW);
  }

  for (int i = 11; i <= 13; i++) {
	  digitalWrite(i, LOW);
  }

  irrecv.enableIRIn();  // Start the IR receiver
}

void loop() {
  if (irrecv.decode(&results)) {

    //============================================================= Turn ON the LEDs =============================================================

    if (results.value == CH_UP) {
      if (w_val >= 0 && w_val < 4) {
        analogWrite(whiteLED[w_val], brightness);
        w_val++;
      } else if (w_val == 4 && rgb_val >= 0 && rgb_val < 7) {
        rgb_state = 1;
        switch (rgb_val) {
          case 0:
            RED();
            rgb_val++;
            rgb_cycle++;
            break;

          case 1:
            GREEN();
            rgb_val++;
            break;

          case 2:
            BLUE();
            rgb_val++;
            break;

          case 3:
            RED_GREEN();
            rgb_val++;
            break;

          case 4:
            RED_BLUE();
            rgb_val++;
            break;

          case 5:
            GREEN_BLUE();
            rgb_val++;
            break;

          case 6:
            RGB_WHITE();
            rgb_val = 0;
            break;
        }
      }
    }

    //============================================================= Turn OFF the LEDs =============================================================

    if (results.value == CH_DOWN) {
      if (w_val == 4 && rgb_state == 1) {
        if(rgb_cycle >= 0){
          switch(rgb_val){
            case 0:
              GREEN_BLUE();
              rgb_val=6;
              break;

            case 1:
              RGB_WHITE();
              rgb_val--;
              rgb_cycle--;
              break;

            case 2:
              RED();
              rgb_val--;
              break;

            case 3:
              GREEN();
              rgb_val--;
              break;

            case 4:
              BLUE();
              rgb_val--;
              break;

            case 5:
              RED_GREEN();
              rgb_val--;
              break;

            case 6:
              RED_BLUE();
              rgb_val--;
              break;
          }
        }
        if (rgb_cycle == -1){
          RGB_OFF();
          rgb_state = 0;
        }
      } else if (w_val <= 4 && w_val > 0) {
        analogWrite(whiteLED[w_val - 1], 0);
        w_val--;
      }
    }

    //============================================================= Increase the Brightness of White LEDs =============================================================
	
    if (results.value == VOL_UP) {
      if (brightness > 0 && brightness <= 225) {
        brightness += 25;
        for (int i = 0; i < w_val; i++) {
          analogWrite(whiteLED[i], brightness);
        }
      }
    }

    //============================================================= Reduce the Brightness of White LEDs =============================================================
	
    if (results.value == VOL_DOWN) {
      if (brightness <= 255 && brightness >= 25) {
        brightness -= 25;
        for (int i = 0; i < w_val; i++) {
          analogWrite(whiteLED[i], brightness);
        }
      }
    }

    irrecv.resume();  // Prepare to receive the next value
  }
}	// End of Main (Loop) Function


//=================== RGB OFF ===================
void RGB_OFF() {
  digitalWrite(R, LOW);
  digitalWrite(G, LOW);
  digitalWrite(B, LOW);
}

//=================== RGB RED ===================
void RED() {
  digitalWrite(R, HIGH);
  digitalWrite(G, LOW);
  digitalWrite(B, LOW);
}

//=================== RGB GREEN ===================
void GREEN() {
  digitalWrite(R, LOW);
  digitalWrite(G, HIGH);
  digitalWrite(B, LOW);
}

//=================== RGB BLUE ===================
void BLUE() {
  digitalWrite(R, LOW);
  digitalWrite(G, LOW);
  digitalWrite(B, HIGH);
}

//=================== RGB YELLOW ===================
void RED_GREEN() {
  digitalWrite(R, HIGH);
  digitalWrite(G, HIGH);
  digitalWrite(B, LOW);
}

//=================== RGB MAGENTA ===================
void RED_BLUE() {
  digitalWrite(R, HIGH);
  digitalWrite(G, LOW);
  digitalWrite(B, HIGH);
}

//=================== RGB CYAN ===================
void GREEN_BLUE() {
  digitalWrite(R, LOW);
  digitalWrite(G, HIGH);
  digitalWrite(B, HIGH);
}

//=================== RGB WHITE ===================
void RGB_WHITE() {
  digitalWrite(R, HIGH);
  digitalWrite(G, HIGH);
  digitalWrite(B, HIGH);
}
